ArrayXcf v = ArrayXcf::Random(3);
cout << v << endl << endl;
cout << arg(v) << endl;
